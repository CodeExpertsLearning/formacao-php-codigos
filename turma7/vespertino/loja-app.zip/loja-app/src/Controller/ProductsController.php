<?php
namespace LojaApp\Controller;

class ProductsController
{
    public function index()
    {
        return 'Produtos encontrados...';
    }
}